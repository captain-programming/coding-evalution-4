function navbar(){
    return `
    <h1><a href="index.html">News App</a></h1>
      <input id="input" placeholder="Search News">
      `;
}

export default navbar;